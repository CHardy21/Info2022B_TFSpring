
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `events`
--

CREATE TABLE `events` (
  `id` bigint(20) NOT NULL,
  `creation_date` datetime DEFAULT NULL,
  `event_active` bit(1) DEFAULT NULL,
  `event_location` varchar(255) DEFAULT NULL,
  `event_name` varchar(255) DEFAULT NULL,
  `organizations_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `events`
--

INSERT INTO `events` (`id`, `creation_date`, `event_active`, `event_location`, `event_name`, `organizations_id`) VALUES(1, '2022-12-13 15:56:06', b'1', 'El Consultorio nro. 2300', 'Consulta medica', 1);
