
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` bigint(20) NOT NULL,
  `user_active` tinyint(1) DEFAULT 1,
  `user_create_date` datetime DEFAULT NULL,
  `user_dni` varchar(8) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `org_lastname` varchar(30) DEFAULT NULL,
  `user_name` varchar(30) DEFAULT NULL,
  `user_phone` bigint(20) NOT NULL,
  `user_token` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `user_active`, `user_create_date`, `user_dni`, `user_email`, `org_lastname`, `user_name`, `user_phone`, `user_token`) VALUES(1, 1, '2022-12-19 13:38:43', '24252627', 'email_user-001@gmail.com', 'Torio', 'Susana', 3624555555, 'email_user-001@gmail.com3624555555');
INSERT INTO `users` (`id`, `user_active`, `user_create_date`, `user_dni`, `user_email`, `org_lastname`, `user_name`, `user_phone`, `user_token`) VALUES(2, 0, '2022-12-19 13:42:03', '24509509', 'email_user-002@gmail.com', 'Queroso', 'Matias', 3624666666, 'email_user-002@gmail.com3624666666');
INSERT INTO `users` (`id`, `user_active`, `user_create_date`, `user_dni`, `user_email`, `org_lastname`, `user_name`, `user_phone`, `user_token`) VALUES(3, 1, '2022-12-19 13:42:04', '24509204', 'email_user-003@gmail.com', 'Dito', 'Igor', 3625444444, 'email_user-003@gmail.com3624666666');
INSERT INTO `users` (`id`, `user_active`, `user_create_date`, `user_dni`, `user_email`, `org_lastname`, `user_name`, `user_phone`, `user_token`) VALUES(5, 0, '2022-12-19 18:24:58', '23555777', 'oscar_acol@email', 'Acolito', 'Oscar', 12345543, 'tokenoscar_acol@email12345543');
